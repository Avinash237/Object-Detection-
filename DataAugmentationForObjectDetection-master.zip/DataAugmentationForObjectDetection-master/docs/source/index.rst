Data Augmentation for Object Detection
======================================

The :mod:`data_aug` package consists of popular image transformations as well as their corresponding bounding box transformations.

.. toctree::
    :maxdepth: 2
    :caption: Package Reference

    data_aug
    bbox_util

